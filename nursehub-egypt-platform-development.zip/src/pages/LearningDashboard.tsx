import { Link } from "react-router-dom";
import { useStore } from "../lib/store";
import { useLMS } from "../lib/lms";
import { useFavorites } from "../lib/favorites";
import { LineChart } from "../components/Charts";
import { PageHeader, StatCard, cardCls, Badge } from "../admin/cms/ui";
import Icon from "../components/Icon";

const BADGE_META: Record<string, { name: string; icon: string }> = {
  first_article: { name: "الخطوة الأولى", icon: "👣" },
  streak_3: { name: "3 أيام متتالية", icon: "🔥" },
  streak_7: { name: "محارب الأسبوع", icon: "⚡" },
  streak_30: { name: "سيد الشهر", icon: "🏆" },
  quiz_5: { name: "بداية الاختبارات", icon: "🎯" },
  quiz_20: { name: "بطل الاختبارات", icon: "🥇" },
  notes_10: { name: "كاتب الملاحظات", icon: "📝" },
  bookmarks_20: { name: "المجمّع", icon: "📚" },
  level_5: { name: "المستوى 5", icon: "⭐" },
  level_10: { name: "المستوى 10", icon: "🌟" },
  level_20: { name: "المستوى 20", icon: "💎" },
};

export default function LearningDashboard() {
  const lms = useLMS();
  const store = useStore();
  const { favorites } = useFavorites();

  const { gamification, readingHistory, flashcards, studyPlan } = lms;
  const { stats } = lms;

  // Continue learning (most recent incomplete article)
  const recentArticles = [...readingHistory]
    .sort((a, b) => b.date.localeCompare(a.date))
    .slice(0, 6);

  const xpProgress = gamification.xp - ((gamification.level - 1) ** 2 * 100);
  const xpNeeded = gamification.level ** 2 * 100 - ((gamification.level - 1) ** 2 * 100);
  const xpPct = Math.min(100, (xpProgress / xpNeeded) * 100);

  const completedFlashcards = flashcards.filter((f) => f.mastered).length;
  const reviewDue = flashcards.filter((f) => !f.mastered && (!f.nextReview || f.nextReview <= new Date().toISOString().slice(0, 10))).length;

  return (
    <div>
      <PageHeader title="لوحة التعلّم" subtitle="تتبع تقدّمك واستأنف تعلّمك" icon="🎓" />

      {/* XP Banner */}
      <div className="mb-6 rounded-2xl bg-gradient-to-l from-sky-500 via-indigo-500 to-purple-600 p-5 text-white shadow-lg shadow-indigo-500/20">
        <div className="flex items-center justify-between gap-4">
          <div>
            <div className="text-sm opacity-80">المستوى {gamification.level}</div>
            <div className="text-3xl font-black">{gamification.xp} XP</div>
            <div className="mt-1 text-xs opacity-60">{xpProgress} / {xpNeeded} XP للمستوى التالي</div>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-4xl">🔥</span>
            <div>
              <div className="text-2xl font-black">{gamification.streak}</div>
              <div className="text-xs opacity-70">أيام متتالية</div>
            </div>
          </div>
          <div className="text-5xl">🏅</div>
        </div>
        <div className="mt-4 h-3 overflow-hidden rounded-full bg-white/20">
          <div className="h-full rounded-full bg-white transition-all" style={{ width: `${xpPct}%` }} />
        </div>
      </div>

      {/* Stats */}
      <div className="mb-6 grid grid-cols-2 gap-3 sm:grid-cols-4">
        <StatCard label="إجمالي وقت الدراسة" value={`${Math.round(stats.totalStudyTime / 60)} د`} icon="⏱️" gradient="from-sky-500 to-blue-500" />
        <StatCard label="مقالات مقروءة" value={stats.articlesRead} icon="📖" gradient="from-emerald-500 to-teal-500" />
        <StatCard label="بطاقات مُتقنة" value={completedFlashcards} icon="🃏" gradient="from-violet-500 to-purple-500" />
        <StatCard label="بطاقات للمراجعة" value={reviewDue} icon="🔄" gradient="from-amber-500 to-orange-500" />
      </div>

      <div className="mb-6 grid gap-4 lg:grid-cols-3">
        {/* Weekly Progress */}
        <div className={`${cardCls} p-5 lg:col-span-2`}>
          <h3 className="mb-4 font-bold dark:text-white">📈 التقدم الأسبوعي (دقائق)</h3>
          <LineChart data={stats.weeklyProgress.map((w) => ({ label: w.day.slice(0, 3), value: w.minutes }))} />
        </div>

        {/* Badges */}
        <div className={`${cardCls} p-5`}>
          <h3 className="mb-4 font-bold dark:text-white">🏅 الشارات ({gamification.badges.length})</h3>
          <div className="grid grid-cols-3 gap-2">
            {Object.entries(BADGE_META).map(([id, m]) => {
              const earned = gamification.badges.includes(id);
              return (
                <div key={id} className={`flex flex-col items-center gap-1 rounded-xl p-2 text-center text-xs ${earned ? "bg-emerald-50 dark:bg-emerald-500/10" : "bg-slate-50 opacity-40 dark:bg-slate-800"}`}>
                  <span className="text-2xl">{m.icon}</span>
                  <span className="font-medium text-slate-700 dark:text-slate-300">{m.name}</span>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Daily Challenges */}
      <div className={`${cardCls} mb-6 p-5`}>
        <h3 className="mb-4 font-bold dark:text-white">🎯 التحديات اليومية</h3>
        <div className="grid gap-2 sm:grid-cols-2">
          {gamification.dailyChallenges.map((c) => (
            <div key={c.id} className={`flex items-center justify-between rounded-xl px-4 py-3 ${c.completed ? "bg-emerald-50 dark:bg-emerald-500/10" : "bg-slate-50 dark:bg-slate-800/50"}`}>
              <div className="flex items-center gap-3">
                <span className={`flex h-7 w-7 items-center justify-center rounded-full text-xs font-black ${c.completed ? "bg-emerald-500 text-white" : "bg-slate-200 text-slate-500 dark:bg-slate-700"}`}>
                  {c.completed ? "✓" : `${c.current}/${c.target}`}
                </span>
                <span className="text-sm font-medium text-slate-700 dark:text-slate-200">{c.desc}</span>
              </div>
              {c.completed && <Badge tone="green">مكتمل</Badge>}
            </div>
          ))}
        </div>
      </div>

      <div className="mb-6 grid gap-4 lg:grid-cols-2">
        {/* Continue Learning */}
        <div className={`${cardCls} p-5`}>
          <div className="mb-4 flex items-center justify-between">
            <h3 className="font-bold dark:text-white">▶️ متابعة التعلّم</h3>
            {recentArticles.length > 0 && <Link to={`/article/${recentArticles[0].slug}`} className="text-xs font-bold text-sky-500 hover:underline">عرض الكل</Link>}
          </div>
          {recentArticles.length ? (
            <div className="space-y-2">
              {recentArticles.map((r) => (
                <Link key={r.id} to={`/article/${r.slug}`} className="flex items-center justify-between rounded-xl px-3 py-2.5 hover:bg-slate-50 dark:hover:bg-slate-800/50">
                  <div className="min-w-0">
                    <div className="truncate text-sm font-medium text-slate-700 dark:text-slate-200">{r.articleTitle}</div>
                    <div className="text-xs text-slate-400">{Math.round(r.duration / 60)} دقيقة · {Math.round(r.scrollPct)}%</div>
                  </div>
                  <Icon name="arrowLeft" size={16} />
                </Link>
              ))}
            </div>
          ) : (
            <p className="py-8 text-center text-sm text-slate-400">لم تبدأ القراءة بعد. ابدأ بمقال جديد!</p>
          )}
        </div>

        {/* Saved Articles */}
        <div className={`${cardCls} p-5`}>
          <div className="mb-4 flex items-center justify-between">
            <h3 className="font-bold dark:text-white">❤️ المحفوظات</h3>
            {favorites.length > 0 && <Link to="/favorites" className="text-xs font-bold text-sky-500 hover:underline">عرض الكل</Link>}
          </div>
          {favorites.length ? (
            <div className="space-y-2">
              {favorites.map((id) => {
                const a = store.articles.find((x: any) => x.id === id);
                if (!a) return null;
                return (
                  <Link key={id} to={`/article/${a.slug}`} className="flex items-center justify-between rounded-xl px-3 py-2.5 hover:bg-slate-50 dark:hover:bg-slate-800/50">
                    <div className="min-w-0">
                      <div className="truncate text-sm font-medium text-slate-700 dark:text-slate-200">{a.title}</div>
                      <div className="text-xs text-slate-400">{a.publishDate}</div>
                    </div>
                    <Icon name="heartFilled" size={16} />
                  </Link>
                );
              })}
            </div>
          ) : (
            <p className="py-8 text-center text-sm text-slate-400">لا توجد مقالات محفوظة</p>
          )}
        </div>
      </div>

      {/* Bookmarks */}
      <div className={`${cardCls} mb-6 p-5`}>
        <div className="mb-4 flex items-center justify-between">
          <h3 className="font-bold dark:text-white">🔖 العلامات المرجعية</h3>
          <Link to="/learning/bookmarks" className="text-xs font-bold text-sky-500 hover:underline">إدارة</Link>
        </div>
        {lms.bookmarks.length ? (
          <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
            {lms.bookmarks.slice(0, 6).map((b) => (
              <Link key={b.id} to={`/article/${b.slug}`} className="rounded-xl border border-slate-100 bg-white p-3 hover:border-sky-200 dark:border-slate-800 dark:bg-slate-900 dark:hover:border-sky-900">
                <div className="truncate text-sm font-medium text-slate-700 dark:text-slate-200">{b.title}</div>
                <div className="mt-1 text-xs text-slate-400">{b.createdAt.slice(0, 10)}</div>
              </Link>
            ))}
          </div>
        ) : (
          <p className="py-6 text-center text-sm text-slate-400">لا توجد علامات مرجعية</p>
        )}
      </div>

      {/* Notes */}
      <div className={`${cardCls} mb-6 p-5`}>
        <div className="mb-4 flex items-center justify-between">
          <h3 className="font-bold dark:text-white">📝 الملاحظات</h3>
          <Link to="/learning/notes" className="text-xs font-bold text-sky-500 hover:underline">عرض الكل ({lms.notes.length})</Link>
        </div>
        {lms.notes.length ? (
          <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
            {lms.notes.slice(0, 6).map((n) => (
              <div key={n.id} className="rounded-xl border border-slate-100 bg-white p-3 dark:border-slate-800 dark:bg-slate-900">
                <div className="flex items-center gap-2">
                  <div className="h-3 w-3 rounded-full" style={{ background: n.color }} />
                  <span className="truncate text-xs text-slate-400">{n.articleTitle}</span>
                </div>
                <p className="mt-1 truncate text-sm text-slate-600 dark:text-slate-300">{n.text}</p>
              </div>
            ))}
          </div>
        ) : (
          <p className="py-6 text-center text-sm text-slate-400">لا توجد ملاحظات</p>
        )}
      </div>

      {/* Study Plan */}
      {studyPlan && (
        <div className={`${cardCls} mb-6 p-5`}>
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-bold dark:text-white">📅 خطة الدراسة</h3>
              <p className="text-sm text-slate-500 dark:text-slate-400">الهدف اليومي: {studyPlan.dailyGoal} دقيقة · الأسبوعي: {studyPlan.weeklyGoal} مقالات</p>
            </div>
            {studyPlan.examDate && (
              <div className="text-center">
                <div className="text-xs text-slate-400">موعد الاختبار</div>
                <div className="font-black text-sky-500">{studyPlan.examDate}</div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
