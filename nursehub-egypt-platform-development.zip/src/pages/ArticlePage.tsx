import { useEffect, useMemo, useRef, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { useStore, readingTime } from "../lib/store";
import { useToast } from "../components/Toast";
import { useFavorites } from "../lib/favorites";
import { useI18n, bilingual } from "../lib/i18n";
import { useSEO, breadcrumbSchema } from "../lib/seo";
import ReadingProgress from "../components/ReadingProgress";
import { SmartBlock } from "../components/article/Blocks";
import { AuthorCard, ShareBar, ArticleNav } from "../components/article/ArticleMeta";
import Icon from "../components/Icon";

const CAT_LABELS: Record<string, string> = {
  articles: "المقالات", summaries: "الملخصات", drugs: "الأدوية",
  skills: "المهارات", careplans: "خطط الرعاية", books: "الكتب",
};

function buildTocFromHtml(html: string, blocks: any[] = []) {
  const headings: { id: string; level: number; text: string }[] = [];
  let i = 0;
  const withIds = html.replace(/<h([23])>(.*?)<\/h\1>/g, (_, lvl, text) => {
    const id = `h-${i}`;
    headings.push({ id, level: Number(lvl), text: text.replace(/<[^>]+>/g, "") });
    i++;
    return `<h${lvl} id="${id}">${text}</h${lvl}>`;
  });

  const blockHeadings = blocks.filter((b) => b.title).map((b, idx) => ({
    id: `b-${idx}`, level: 3, text: b.title,
  }));

  return { headings: [...headings, ...blockHeadings], withIds };
}

export default function ArticlePage() {
  const { slug } = useParams();
  const { articles, settings, setData, logActivity } = useStore();
  const { notify } = useToast();
  const { isFav, toggleFav } = useFavorites();
  const { lang, t } = useI18n();
  const articleRef = useRef<HTMLDivElement>(null);
  const [mobileToc, setMobileToc] = useState(false);

  const article = articles.find((a: any) => a.slug === slug);

  const displayTitle = bilingual(article?.title, article?.titleEn, lang).text;
  const displayContent = article ? (lang === "en" && article.contentEn ? article.contentEn : (article.content || "")) : "";
  const displayExcerpt = bilingual(article?.excerpt, article?.excerptEn, lang).text;

  // Parse smart blocks from content (if stored as JSON blocks)
  const smartBlocks = useMemo(() => {
    try {
      const m = displayContent?.match(/<!--\s*blocks\s*:\s*(\[[\s\S]*?\])\s*-->/);
      return m ? JSON.parse(m[1]) : [];
    } catch { return []; }
  }, [displayContent]);

  // TOC
  const toc = useMemo(() => {
    const cleanContent = displayContent?.replace(/<!-- blocks:.*?-->/gs, "") || "";
    return buildTocFromHtml(cleanContent, smartBlocks);
  }, [displayContent, smartBlocks]);

  const mins = article ? readingTime(displayContent) : 0;

  // Scroll tracking
  useEffect(() => {
    if (article) {
      window.scrollTo({ top: 0 });
      logActivity("قراءة مقال", article.title);
      setData((d: any) => ({ ...d, articles: d.articles.map((a: any) => (a.id === article.id ? { ...a, views: a.views + 1 } : a)) }));
    }
  }, [slug]);



  useSEO({
    title: displayTitle ? `${displayTitle} | ${settings.siteName}` : t("article.notFound"),
    description: displayExcerpt,
    keywords: article?.tags?.join(", "),
    image: article?.cover,
    type: "article",
    jsonLd: article
      ? [
          { "@context": "https://schema.org", "@type": "Article", headline: displayTitle, description: displayExcerpt, image: article.cover, author: { "@type": "Person", name: article.author }, datePublished: article.publishDate, dateModified: article.updatedDate || article.publishDate, publisher: { "@type": "Organization", name: settings.siteName } },
          breadcrumbSchema([
            { name: t("nav.home"), url: window.location.origin },
            { name: CAT_LABELS[article.category] || article.category, url: `${window.location.origin}/category/${article.category}` },
            { name: displayTitle, url: window.location.href },
          ]),
        ]
      : undefined,
  });

  // Related articles
  const related = useMemo(() => {
    if (!article) return [];
    return articles.filter((a: any) => a.category === article.category && a.id !== article.id && a.status === "published").slice(0, 4);
  }, [article, articles]);

  // Prev/Next
  const published = useMemo(() => articles.filter((a: any) => a.status === "published"), [articles]);
  const currentIdx = useMemo(() => published.findIndex((a: any) => a.slug === slug), [published, slug]);
  const prevArticle = published[currentIdx - 1];
  const nextArticle = published[currentIdx + 1];

  if (!article) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-20 text-center">
        <div className="text-6xl mb-4">🔍</div>
        <h1 className="text-2xl font-black dark:text-white">{t("article.notFound")}</h1>
        <Link to="/" className="mt-4 inline-block rounded-full bg-sky-500 px-6 py-2.5 font-bold text-white">{t("article.backHome")}</Link>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-7xl px-4 py-6">
      <ReadingProgress />

      {/* Breadcrumb */}
      <nav className="mb-4 flex flex-wrap items-center gap-1 text-sm text-slate-500 dark:text-slate-400">
        <Link to="/" className="hover:text-sky-500">{t("nav.home")}</Link>
        <span className="text-slate-300">/</span>
        <Link to={`/category/${article.category}`} className="hover:text-sky-500">{CAT_LABELS[article.category] || article.category}</Link>
        <span className="text-slate-300">/</span>
        <span className="font-medium text-slate-700 dark:text-slate-200 truncate">{displayTitle}</span>
      </nav>

      <div className="grid gap-8 lg:grid-cols-[1fr_280px]">
        {/* Main article */}
        <div ref={articleRef} className="min-w-0">
          <article>
            {/* Category + Favorite + Mobile TOC */}
            <div className="mb-3 flex items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <span className="rounded-full bg-sky-50 px-3 py-1 text-xs font-bold text-sky-600 dark:bg-sky-500/10">
                  <Icon name="article" size={14} /> {CAT_LABELS[article.category] || article.category}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <button onClick={() => { toggleFav(article.id); notify(isFav(article.id) ? "تمت الإزالة" : "تمت الإضافة إلى المفضلة", "info"); }}
                  className={`flex items-center gap-1.5 rounded-full border px-3 py-1 text-xs font-bold transition ${isFav(article.id) ? "border-rose-300 bg-rose-50 text-rose-500 dark:border-rose-900 dark:bg-rose-500/10" : "border-slate-200 text-slate-500 dark:border-slate-700"}`}>
                  <Icon name={isFav(article.id) ? "heartFilled" : "heart"} size={13} /> {isFav(article.id) ? t("common.saved") : t("common.save")}
                </button>
                <button onClick={() => setMobileToc((m) => !m)} className="lg:hidden flex h-8 w-8 items-center justify-center rounded-full border border-slate-200 text-sm dark:border-slate-700 dark:text-white">📑</button>
              </div>
            </div>

            {/* Title */}
            <h1 className="text-2xl font-black leading-tight text-slate-800 dark:text-white md:text-3xl lg:text-4xl">{displayTitle}</h1>

            {/* Meta */}
            <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-2 text-sm text-slate-500 dark:text-slate-400">
              <span className="inline-flex items-center gap-1"><Icon name="user" size={14} /> {article.author}</span>
              <span className="inline-flex items-center gap-1"><Icon name="calendar" size={14} /> {article.publishDate}</span>
              {article.updatedDate && <span className="inline-flex items-center gap-1"><Icon name="calendar" size={14} /> آخر تحديث: {article.updatedDate}</span>}
              <span className="inline-flex items-center gap-1"><Icon name="eye" size={14} /> {article.views.toLocaleString("ar-EG")} {t("article.views")}</span>
              <span className="inline-flex items-center gap-1"><Icon name="article" size={14} /> {mins} {t("article.readingTime")}</span>
              {article.ratingCount ? <span className="inline-flex items-center gap-0.5">
                {[...Array(5)].map((_, i) => <Icon key={i} name={i < Math.round(article.rating || 0) ? "starFilled" : "star"} size={14} />)}
                <span className="ml-1">{article.rating?.toFixed(1)}</span>
              </span> : null}
            </div>

            {/* Medical disclaimer */}
            <div className="mt-4 flex items-start gap-2 rounded-xl border border-amber-200 bg-amber-50 px-4 py-2.5 text-xs text-amber-700 dark:border-amber-900 dark:bg-amber-500/5 dark:text-amber-400">
              <span className="text-base">⚕️</span>
              <p>{lang === "ar"
                ? "إخلاء مسؤولية طبي: هذا المحتوى لأغراض تعليمية فقط ولا يُغني عن استشارة الطبيب أو المختص. راجع دائماً البروتوكولات المعتمدة في مؤسستك."
                : "Medical Disclaimer: This content is for educational purposes only and is not a substitute for professional medical advice."}</p>
            </div>

            {/* Cover image */}
            {article.cover && (
              <div className="mt-5 overflow-hidden rounded-2xl">
                <img src={article.cover} alt={displayTitle} loading="lazy" className="h-64 w-full object-cover md:h-96" />
              </div>
            )}

            {/* Share bar */}
            <ShareBar title={displayTitle} slug={article.slug} />

            {/* Content */}
            <div className="prose-content reading-measure text-slate-700 dark:text-slate-300" dangerouslySetInnerHTML={{ __html: toc.withIds }} />

            {/* Smart blocks */}
            {smartBlocks.map((block: any, i: number) => <SmartBlock key={i} block={block} />)}

            {/* Attachments */}
            {article.attachments?.length ? (
              <div className="my-6 space-y-2">
                <h3 className="flex items-center gap-2 font-bold text-slate-700 dark:text-slate-200"><Icon name="article" size={18} /> Downloads</h3>
                {article.attachments.map((f: any) => (
                  <a key={f.name} href={f.url} className="flex items-center justify-between rounded-xl border border-slate-200 bg-white p-3 hover:border-sky-300 dark:border-slate-800 dark:bg-slate-900">
                    <span className="text-sm font-medium dark:text-white">{f.name}</span>
                    <span className="rounded-full bg-sky-500 px-3 py-1 text-xs font-bold text-white">Download</span>
                  </a>
                ))}
              </div>
            ) : null}

            {/* Tags */}
            {article.tags?.length > 0 && (
              <div className="mt-6 flex flex-wrap gap-2">
                {article.tags.map((tag: string) => (
                  <Link key={tag} to={`/search?q=${encodeURIComponent(tag)}`} className="rounded-full bg-slate-100 px-3 py-1 text-xs font-medium text-slate-600 hover:bg-sky-100 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-sky-500/10">#{tag}</Link>
                ))}
              </div>
            )}

            {/* Author card */}
            <AuthorCard name={article.author} role="Nursing Educator" bio={lang === "ar" ? "محتوى تعليمي متخصص في التمريض تم مراجعته من فريق طبي معتمد." : "Specialized nursing education content reviewed by certified medical team."} />

            {/* Prev / Next */}
            <ArticleNav prev={prevArticle ? { title: bilingual(prevArticle.title, prevArticle.titleEn, lang).text, slug: prevArticle.slug } : undefined} next={nextArticle ? { title: bilingual(nextArticle.title, nextArticle.titleEn, lang).text, slug: nextArticle.slug } : undefined} />
          </article>

          {/* Related */}
          {related.length > 0 && (
            <section className="mt-10">
              <h2 className="mb-5 text-xl font-black text-slate-800 dark:text-white">{t("article.related")}</h2>
              <div className="grid gap-5 sm:grid-cols-2">
                {related.map((a: any) => {
                  const tt = bilingual(a.title, a.titleEn, lang).text;
                  return (
                    <Link key={a.id} to={`/article/${a.slug}`} className="group overflow-hidden rounded-2xl border border-slate-200 bg-white transition hover:shadow-lg dark:border-slate-800 dark:bg-slate-900">
                      {a.cover && <img src={a.cover} alt={tt} loading="lazy" className="h-36 w-full object-cover transition group-hover:scale-105" />}
                      <div className="p-4">
                        <h3 className="font-bold text-slate-800 group-hover:text-sky-500 dark:text-white">{tt}</h3>
                        <div className="mt-1 flex items-center gap-2 text-xs text-slate-400"><Icon name="eye" size={12} /> {a.views.toLocaleString("ar-EG")}</div>
                      </div>
                    </Link>
                  );
                })}
              </div>
            </section>
          )}
        </div>

        {/* Sticky sidebar — TOC (desktop) */}
        <aside className="hidden lg:block">
          {toc.headings.length > 0 ? (
            <div className="sticky top-20 max-h-[calc(100vh-5rem)] overflow-y-auto rounded-2xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900">
              <h3 className="mb-3 flex items-center gap-2 text-sm font-extrabold text-slate-700 dark:text-slate-200">
                <Icon name="article" size={16} /> Table of Contents
              </h3>
              <ul className="space-y-1.5">
                {toc.headings.map((h) => (
                  <li key={h.id}>
                    <a href={`#${h.id}`} className={`block text-sm transition hover:text-sky-500 ${h.level === 2 ? "font-bold text-slate-700 dark:text-slate-200" : "ml-3 text-slate-500 dark:text-slate-400"}`}>
                      {h.text}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ) : null}
        </aside>

        {/* Mobile TOC modal */}
        {mobileToc && toc.headings.length > 0 && (
          <div className="fixed inset-0 z-50 lg:hidden" onClick={() => setMobileToc(false)}>
            <div className="absolute inset-0 bg-black/50" />
            <div className="absolute left-4 right-4 top-1/2 max-h-[80vh] -translate-y-1/2 overflow-y-auto rounded-2xl bg-white p-5 dark:bg-slate-900" onClick={(e) => e.stopPropagation()}>
              <div className="mb-4 flex items-center justify-between">
                <h3 className="font-extrabold text-slate-700 dark:text-slate-200">Table of Contents</h3>
                <button onClick={() => setMobileToc(false)} className="text-slate-400">✕</button>
              </div>
              <ul className="space-y-2">
                {toc.headings.map((h) => (
                  <li key={h.id}>
                    <a href={`#${h.id}`} onClick={() => setMobileToc(false)} className={`block text-sm transition hover:text-sky-500 ${h.level === 2 ? "font-bold text-slate-700 dark:text-slate-200" : "ml-4 text-slate-500 dark:text-slate-400"}`}>{h.text}</a>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
