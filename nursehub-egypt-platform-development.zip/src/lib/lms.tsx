import { createContext, useContext, useEffect, useState, useCallback, type ReactNode } from "react";
import type {
  Bookmark, StudyNote, Flashcard, StudyPlan, Gamification, ReadingHistory, LearningStats,
} from "../lib/types";

/* ===================== Storage Keys ===================== */
const KEY_PREFIX = "nursehub_lms_";
const key = (k: string) => `${KEY_PREFIX}${k}`;

/* ===================== Helpers ===================== */
function load<T>(k: string, fallback: T): T {
  try { const raw = localStorage.getItem(key(k)); return raw ? JSON.parse(raw) : fallback; }
  catch { return fallback; }
}
function save<T>(k: string, v: T) { try { localStorage.setItem(key(k), JSON.stringify(v)); } catch { /* quota */ } }

function uid() { return "lms" + Date.now() + Math.random().toString(36).slice(2, 7); }
function today() { return new Date().toISOString().slice(0, 10); }

const DAILY_CHALLENGES = [
  { id: "read_3", desc: "اقرأ 3 مقالات", target: 3 },
  { id: "quiz_1", desc: "أكمل اختباراً واحداً", target: 1 },
  { id: "note_1", desc: "أضف ملاحظة جديدة", target: 1 },
  { id: "flashcard_5", desc: "راجع 5 بطاقات", target: 5 },
];

function calcLevel(xp: number): number {
  return Math.floor(1 + Math.sqrt(xp / 100));
}

/* ===================== Context ===================== */
interface LMSData {
  bookmarks: Bookmark[];
  notes: StudyNote[];
  flashcards: Flashcard[];
  studyPlan: StudyPlan | null;
  gamification: Gamification;
  readingHistory: ReadingHistory[];
}

interface LMSContext extends LMSData {
  /* Bookmarks */
  addBookmark: (articleId: string, title: string, slug: string, category: string) => void;
  removeBookmark: (id: string) => void;
  /* Notes */
  addNote: (articleId: string, articleTitle: string, text: string, color?: string, highlightedText?: string) => void;
  updateNote: (id: string, text: string) => void;
  removeNote: (id: string) => void;
  /* Flashcards */
  addFlashcard: (front: string, back: string, category: string, articleId?: string) => void;
  updateFlashcard: (id: string, updates: Partial<Flashcard>) => void;
  removeFlashcard: (id: string) => void;
  reviewFlashcard: (id: string, remembered: boolean) => void;
  /* Study Plan */
  setStudyPlan: (plan: StudyPlan) => void;
  /* Reading History */
  logReading: (articleId: string, articleTitle: string, slug: string, durationSec: number, scrollPct: number) => void;
  /* Gamification */
  addXP: (amount: number) => void;
  recordDailyAction: (actionType: string) => void;
  /* Stats */
  stats: LearningStats;
  /* Reset */
  resetAll: () => void;
}

const Ctx = createContext<LMSContext | null>(null);

const DEFAULT_GAMIFICATION: Gamification = {
  id: "gam1", userId: "user1", xp: 0, level: 1, streak: 0, bestStreak: 0,
  lastStudyDate: "", badges: [], dailyChallenges: DAILY_CHALLENGES.map((c) => ({ ...c, current: 0, completed: false })),
};

export function LMSProvider({ children }: { children: ReactNode }) {
  const [data, setData] = useState<LMSData>(() => ({
    bookmarks: load("bookmarks", []),
    notes: load("notes", []),
    flashcards: load("flashcards", []),
    studyPlan: load("studyPlan", null),
    gamification: load("gamification", { ...DEFAULT_GAMIFICATION, lastStudyDate: today() }),
    readingHistory: load("readingHistory", []),
  }));

  // Persist on change
  useEffect(() => { save("bookmarks", data.bookmarks); }, [data.bookmarks]);
  useEffect(() => { save("notes", data.notes); }, [data.notes]);
  useEffect(() => { save("flashcards", data.flashcards); }, [data.flashcards]);
  useEffect(() => { save("studyPlan", data.studyPlan); }, [data.studyPlan]);
  useEffect(() => { save("gamification", data.gamification); }, [data.gamification]);
  useEffect(() => { save("readingHistory", data.readingHistory.slice(-500)); }, [data.readingHistory]);

  /* --- Bookmarks --- */
  const addBookmark = useCallback((articleId: string, title: string, slug: string, category: string) => {
    setData((d) => ({
      ...d,
      bookmarks: [{ id: uid(), userId: "user1", articleId, title, slug, category, createdAt: new Date().toISOString() }, ...d.bookmarks],
    }));
  }, []);
  const removeBookmark = useCallback((id: string) => {
    setData((d) => ({ ...d, bookmarks: d.bookmarks.filter((b) => b.id !== id) }));
  }, []);

  /* --- Notes --- */
  const addNote = useCallback((articleId: string, articleTitle: string, text: string, color = "#0ea5e9", highlightedText?: string) => {
    const now = new Date().toISOString();
    setData((d) => ({
      ...d,
      notes: [{ id: uid(), userId: "user1", articleId, articleTitle, text, color, highlightedText, createdAt: now, updatedAt: now }, ...d.notes],
    }));
  }, []);
  const updateNote = useCallback((id: string, text: string) => {
    setData((d) => ({ ...d, notes: d.notes.map((n) => (n.id === id ? { ...n, text, updatedAt: new Date().toISOString() } : n)) }));
  }, []);
  const removeNote = useCallback((id: string) => {
    setData((d) => ({ ...d, notes: d.notes.filter((n) => n.id !== id) }));
  }, []);

  /* --- Flashcards --- */
  const addFlashcard = useCallback((front: string, back: string, category: string, articleId?: string) => {
    setData((d) => ({
      ...d,
      flashcards: [{ id: uid(), userId: "user1", articleId, front, back, category, mastered: false, createdAt: new Date().toISOString(), reviewCount: 0 }, ...d.flashcards],
    }));
  }, []);
  const updateFlashcard = useCallback((id: string, updates: Partial<Flashcard>) => {
    setData((d) => ({ ...d, flashcards: d.flashcards.map((f) => (f.id === id ? { ...f, ...updates } : f)) }));
  }, []);
  const removeFlashcard = useCallback((id: string) => {
    setData((d) => ({ ...d, flashcards: d.flashcards.filter((f) => f.id !== id) }));
  }, []);
  const reviewFlashcard = useCallback((id: string, remembered: boolean) => {
    setData((d) => ({
      ...d,
      flashcards: d.flashcards.map((f) => {
        if (f.id !== id) return f;
        const rc = f.reviewCount + 1;
        return { ...f, reviewCount: rc, mastered: rc >= 5 && remembered, lastReviewed: today(), nextReview: remembered ? new Date(Date.now() + 86400000 * 3).toISOString().slice(0, 10) : today() };
      }),
    }));
  }, []);

  /* --- Study Plan --- */
  const setStudyPlan = useCallback((plan: StudyPlan) => {
    setData((d) => ({ ...d, studyPlan: plan }));
  }, []);

  /* --- Reading History --- */
  const logReading = useCallback((articleId: string, articleTitle: string, slug: string, durationSec: number, scrollPct: number) => {
    setData((d) => ({
      ...d,
      readingHistory: [...d.readingHistory, { id: uid(), userId: "user1", articleId, articleTitle, slug, date: new Date().toISOString(), duration: durationSec, scrollPct, device: "web" }],
    }));
  }, []);

  /* --- Gamification --- */
  const addXP = useCallback((amount: number) => {
    setData((d) => {
      const g = d.gamification;
      const newXP = g.xp + amount;
      const newLevel = calcLevel(newXP);
      const newBadges = [...g.badges];

      // Badge checks
      if (newLevel >= 5 && !newBadges.includes("level_5")) newBadges.push("level_5");
      if (newLevel >= 10 && !newBadges.includes("level_10")) newBadges.push("level_10");
      if (newLevel >= 20 && !newBadges.includes("level_20")) newBadges.push("level_20");

      return { ...d, gamification: { ...g, xp: newXP, level: newLevel, badges: newBadges } };
    });
  }, []);

  const recordDailyAction = useCallback((actionType: string) => {
    setData((d) => {
      const g = d.gamification;
      const tdy = today();
      let streak = g.streak;
      if (g.lastStudyDate !== tdy) {
        const yesterday = new Date(Date.now() - 86400000).toISOString().slice(0, 10);
        streak = g.lastStudyDate === yesterday ? streak + 1 : 1;
      }
      const best = Math.max(g.bestStreak, streak);

      const challenges = g.dailyChallenges.map((c) => {
        if (c.id === actionType && !c.completed) {
          const next = { ...c, current: c.current + 1 };
          return { ...next, completed: next.current >= next.target };
        }
        return c;
      });

      const newBadges = [...g.badges];
      if (streak >= 3 && !newBadges.includes("streak_3")) newBadges.push("streak_3");
      if (streak >= 7 && !newBadges.includes("streak_7")) newBadges.push("streak_7");
      if (streak >= 30 && !newBadges.includes("streak_30")) newBadges.push("streak_30");

      return { ...d, gamification: { ...g, streak, bestStreak: best, lastStudyDate: tdy, dailyChallenges: challenges, badges: newBadges } };
    });
  }, []);

  /* --- Stats --- */
  const stats: LearningStats = (() => {
    const rh = data.readingHistory;
    const totalStudyTime = rh.reduce((s, r) => s + r.duration, 0);
    const articlesRead = new Set(rh.map((r) => r.articleId)).size;

    const weekDays = ["الأحد", "الإثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت"];
    const now = new Date();
    const weeklyProgress = weekDays.map((day, i) => {
      const d = new Date(now); d.setDate(now.getDate() - (6 - i));
      const prefix = d.toISOString().slice(0, 10);
      const mins = rh.filter((r) => r.date.startsWith(prefix)).reduce((s, r) => s + r.duration, 0) / 60;
      return { day, minutes: Math.round(mins) };
    });

    const quizAttempts = 0; // would come from quiz_attempts table
    const avgQuizScore = 0;

    return { totalStudyTime, articlesRead, quizzesTaken: quizAttempts, avgQuizScore, currentStreak: data.gamification.streak, weeklyProgress, strongestTopics: [], weakestTopics: [] };
  })();

  const ctx: LMSContext = {
    bookmarks: data.bookmarks,
    notes: data.notes,
    flashcards: data.flashcards,
    studyPlan: data.studyPlan,
    gamification: data.gamification,
    readingHistory: data.readingHistory,
    addBookmark, removeBookmark,
    addNote, updateNote, removeNote,
    addFlashcard, updateFlashcard, removeFlashcard, reviewFlashcard,
    setStudyPlan,
    logReading,
    addXP, recordDailyAction,
    stats,
    resetAll: () => {
      Object.keys(localStorage).filter((k) => k.startsWith(KEY_PREFIX)).forEach((k) => localStorage.removeItem(k));
      setData({ bookmarks: [], notes: [], flashcards: [], studyPlan: null, gamification: { ...DEFAULT_GAMIFICATION, lastStudyDate: today() }, readingHistory: [] });
    },
  };

  return <Ctx.Provider value={ctx}>{children}</Ctx.Provider>;
}

export function useLMS() {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useLMS must be used within LMSProvider");
  return ctx;
}
