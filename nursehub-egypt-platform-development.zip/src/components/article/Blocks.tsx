/** Smart content blocks for NurseHub Egypt — premium nursing handbook style. */
import { useState, type ReactNode } from "react";

const card = "my-5 rounded-xl border px-5 py-4";
const titleCls = "mb-2 flex items-center gap-2 text-base font-extrabold";

export function ClinicalPearl({ title, children }: { title?: string; children: ReactNode }) {
  return (
    <div className={`${card} bg-amber-50 border-amber-200 dark:bg-amber-500/10 dark:border-amber-900/50`}>
      <div className={`${titleCls} text-amber-700 dark:text-amber-400`}>
        <span className="text-lg">🦪</span>{title || "Clinical Pearl"}
      </div>
      <div className="text-sm leading-relaxed text-amber-800 dark:text-amber-200">{children}</div>
    </div>
  );
}

export function NursingTip({ title, children }: { title?: string; children: ReactNode }) {
  return (
    <div className={`${card} bg-emerald-50 border-emerald-200 dark:bg-emerald-500/10 dark:border-emerald-900/50`}>
      <div className={`${titleCls} text-emerald-700 dark:text-emerald-400`}>
        <span className="text-lg">💡</span>{title || "Nursing Tip"}
      </div>
      <div className="text-sm leading-relaxed text-emerald-800 dark:text-emerald-200">{children}</div>
    </div>
  );
}

export function Warning({ title, children }: { title?: string; children: ReactNode }) {
  return (
    <div className={`${card} bg-rose-50 border-rose-200 dark:bg-rose-500/10 dark:border-rose-900/50`}>
      <div className={`${titleCls} text-rose-700 dark:text-rose-400`}>
        <span className="text-lg">⚠️</span>{title || "تحذير"}
      </div>
      <div className="text-sm leading-relaxed text-rose-800 dark:text-rose-200">{children}</div>
    </div>
  );
}

export function DrugCard({ name, dose, indications, sideEffects, considerations }: {
  name: string; dose?: string; indications?: string; sideEffects?: string; considerations?: string;
}) {
  const [open, setOpen] = useState(false);
  return (
    <div className={`${card} bg-sky-50 border-sky-200 dark:bg-sky-500/10 dark:border-sky-900/50`}>
      <button onClick={() => setOpen(!open)} className="w-full text-right">
        <div className={`${titleCls} text-sky-700 dark:text-sky-400`}>
          <span className="text-lg">💊</span>
          <span className="truncate">Drug Card: {name}</span>
          <span className="ml-auto text-xs text-sky-400">{open ? "▲" : "▼"}</span>
        </div>
      </button>
      {open && (
        <div className="mt-3 space-y-3 text-sm text-sky-800 dark:text-sky-200">
          {dose && <div><strong className="text-sky-600 dark:text-sky-300">الجرعة:</strong> {dose}</div>}
          {indications && <div><strong className="text-sky-600 dark:text-sky-300">دواعي الاستعمال:</strong> {indications}</div>}
          {sideEffects && <div><strong className="text-rose-600 dark:text-rose-400">الآثار الجانبية:</strong> {sideEffects}</div>}
          {considerations && <div><strong className="text-sky-600 dark:text-sky-300">اعتبارات تمريضية:</strong> {considerations}</div>}
        </div>
      )}
    </div>
  );
}

export function ProcedureCard({ steps }: { steps: { title: string; desc: string }[] }) {
  return (
    <div className={`${card} bg-violet-50 border-violet-200 dark:bg-violet-500/10 dark:border-violet-900/50`}>
      <div className={`${titleCls} text-violet-700 dark:text-violet-400`}>
        <span className="text-lg">🩺</span> Procedure Steps
      </div>
      <ol className="space-y-3 text-sm">
        {steps.map((s, i) => (
          <li key={i} className="flex gap-3">
            <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-violet-500 text-xs font-bold text-white">{i + 1}</span>
            <div>
              <div className="font-bold text-violet-700 dark:text-violet-300">{s.title}</div>
              <div className="text-violet-600 dark:text-violet-400">{s.desc}</div>
            </div>
          </li>
        ))}
      </ol>
    </div>
  );
}

export function Accordion({ items }: { items: { q: string; a: string }[] }) {
  const [open, setOpen] = useState<number | null>(null);
  return (
    <div className="my-5 space-y-2">
      {items.map((item, i) => (
        <div key={i} className="rounded-lg border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900">
          <button onClick={() => setOpen(open === i ? null : i)} className="w-full px-4 py-3 text-right font-bold text-slate-700 dark:text-slate-200">
            {item.q} <span className="float-left text-slate-400">{open === i ? "▲" : "▼"}</span>
          </button>
          {open === i && <div className="border-t border-slate-100 px-4 py-3 text-sm text-slate-600 dark:border-slate-800 dark:text-slate-300">{item.a}</div>}
        </div>
      ))}
    </div>
  );
}

export function Quiz({ question, options, correct, explanation }: {
  question: string; options: string[]; correct: number; explanation?: string;
}) {
  const [selected, setSelected] = useState<number | null>(null);
  return (
    <div className={`${card} bg-white border-slate-200 dark:bg-slate-900 dark:border-slate-800`}>
      <div className={`${titleCls} text-slate-700 dark:text-slate-200`}>
        <span className="text-lg">🎯</span> Quiz
      </div>
      <p className="mb-3 text-sm font-semibold text-slate-700 dark:text-slate-200">{question}</p>
      <div className="space-y-2">
        {options.map((o, i) => (
          <button key={i} onClick={() => setSelected(i)}
            className={`w-full rounded-lg border px-4 py-2.5 text-right text-sm font-medium transition-all ${
              selected === i
                ? i === correct
                  ? "border-emerald-300 bg-emerald-50 text-emerald-700 dark:border-emerald-800 dark:bg-emerald-500/10"
                  : "border-rose-300 bg-rose-50 text-rose-700 dark:border-rose-800 dark:bg-rose-500/10"
                : "border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300"
            }`}>
            {o} {selected === i && (i === correct ? " ✅" : " ❌")}
          </button>
        ))}
      </div>
      {selected !== null && explanation && (
        <div className="mt-3 rounded-lg bg-sky-50 p-3 text-sm text-sky-700 dark:bg-sky-500/10 dark:text-sky-300">💡 {explanation}</div>
      )}
    </div>
  );
}

export function SummaryBox({ title, children }: { title?: string; children: ReactNode }) {
  return (
    <div className={`${card} bg-slate-50 border-slate-200 dark:bg-slate-800/50 dark:border-slate-700`}>
      <div className={`${titleCls} text-slate-700 dark:text-slate-200`}>
        <span className="text-lg">📋</span>{title || "Summary"}
      </div>
      <div className="text-sm leading-relaxed text-slate-600 dark:text-slate-300">{children}</div>
    </div>
  );
}

export function References({ refs }: { refs: string[] }) {
  return (
    <div className={`${card} bg-slate-50 border-slate-200 dark:bg-slate-800/50 dark:border-slate-700`}>
      <div className={`${titleCls} text-slate-700 dark:text-slate-200`}>
        <span className="text-lg">📚</span> References
      </div>
      <ol className="space-y-2 text-xs text-slate-500 dark:text-slate-400">
        {refs.map((r, i) => <li key={i} className="leading-relaxed">{i + 1}. {r}</li>)}
      </ol>
    </div>
  );
}

/** Smart block renderer — renders block JSON from article content. */
export function SmartBlock({ block }: { block: any }) {
  switch (block?.type) {
    case "clinical_pearl": return <ClinicalPearl title={block.title}>{block.content}</ClinicalPearl>;
    case "nursing_tip": return <NursingTip title={block.title}>{block.content}</NursingTip>;
    case "warning": return <Warning title={block.title}>{block.content}</Warning>;
    case "drug_card": return <DrugCard {...(block.data || {})} />;
    case "procedure": return <ProcedureCard steps={block.data?.steps || []} />;
    case "accordion": return <Accordion items={block.data?.items || []} />;
    case "quiz": return <Quiz {...(block.data || {})} />;
    case "summary": return <SummaryBox title={block.title}>{block.content}</SummaryBox>;
    case "references": return <References refs={block.data?.refs || []} />;
    case "youtube":
      return (
        <div className="my-5 overflow-hidden rounded-xl">
          <iframe src={`https://www.youtube.com/embed/${block.data?.videoId}`} className="aspect-video w-full" allowFullScreen />
        </div>
      );
    case "pdf":
      return (
        <div className="my-5 rounded-xl border border-slate-200 bg-white p-4 text-center dark:border-slate-800 dark:bg-slate-900">
          <div className="text-3xl mb-2">📄</div>
          <a href={block.data?.url} target="_blank" rel="noopener noreferrer" className="inline-block rounded-full bg-sky-500 px-5 py-2 text-sm font-bold text-white hover:bg-sky-600">
            عرض / تحميل {block.data?.name || "PDF"}
          </a>
        </div>
      );
    default:
      return block?.content ? <div className="my-3" dangerouslySetInnerHTML={{ __html: block.content }} /> : null;
  }
}
