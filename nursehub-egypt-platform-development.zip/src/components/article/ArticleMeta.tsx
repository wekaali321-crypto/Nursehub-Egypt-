export function AuthorCard({ name, role, bio, avatar }: { name: string; role?: string; bio?: string; avatar?: string }) {
  return (
    <div className="my-8 flex items-start gap-4 rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
      <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-sky-500 to-emerald-500 text-xl font-black text-white">
        {avatar ? <img src={avatar} alt={name} className="h-full w-full rounded-full object-cover" /> : name.charAt(0)}
      </div>
      <div>
        <div className="text-sm text-slate-400">Written by</div>
        <div className="text-base font-extrabold text-slate-800 dark:text-white">{name}</div>
        {role && <div className="text-xs font-medium text-sky-500">{role}</div>}
        {bio && <p className="mt-2 text-sm leading-relaxed text-slate-500 dark:text-slate-400">{bio}</p>}
      </div>
    </div>
  );
}

export function ShareBar({ title, slug }: { title: string; slug: string }) {
  const url = typeof window !== "undefined" ? `${window.location.origin}/article/${slug}` : "";
  const items = [
    { icon: "📘", label: "Facebook", u: `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}` },
    { icon: "🐦", label: "Twitter", u: `https://twitter.com/intent/tweet?url=${encodeURIComponent(url)}&text=${encodeURIComponent(title)}` },
    { icon: "💬", label: "WhatsApp", u: `https://wa.me/?text=${encodeURIComponent(title + " " + url)}` },
    { icon: "💼", label: "LinkedIn", u: `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(url)}` },
  ];

  const copyLink = () => { navigator.clipboard?.writeText(url); };
  const doPrint = () => { window.print(); };

  return (
    <div className="my-6 flex flex-wrap items-center gap-2">
      <span className="mr-2 text-sm font-bold text-slate-600 dark:text-slate-300">Share:</span>
      {items.map((s) => (
        <a key={s.label} href={s.u} target="_blank" rel="noopener noreferrer" title={s.label}
          className="flex h-10 w-10 items-center justify-center rounded-xl border border-slate-200 bg-white text-lg shadow-sm transition hover:scale-110 dark:border-slate-700 dark:bg-slate-900">
          {s.icon}
        </a>
      ))}
      <button onClick={copyLink} title="Copy link" className="flex h-10 w-10 items-center justify-center rounded-xl border border-slate-200 bg-white text-lg shadow-sm transition hover:scale-110 dark:border-slate-700 dark:bg-slate-900">🔗</button>
      <button onClick={doPrint} title="Print" className="flex h-10 w-10 items-center justify-center rounded-xl border border-slate-200 bg-white text-lg shadow-sm transition hover:scale-110 dark:border-slate-700 dark:bg-slate-900">🖨️</button>
    </div>
  );
}

export function ArticleNav({ prev, next }: { prev?: { title: string; slug: string }; next?: { title: string; slug: string } }) {
  if (!prev && !next) return null;
  return (
    <div className="my-8 grid gap-3 md:grid-cols-2">
      {prev && (
        <a href={`/article/${prev.slug}`} className="rounded-xl border border-slate-200 bg-white p-4 text-right transition hover:border-sky-300 hover:shadow-md dark:border-slate-800 dark:bg-slate-900 dark:hover:border-sky-800">
          <div className="text-xs text-slate-400">← Previous Article</div>
          <div className="mt-1 font-bold text-slate-700 dark:text-slate-200">{prev.title}</div>
        </a>
      )}
      {next && (
        <a href={`/article/${next.slug}`} className="rounded-xl border border-slate-200 bg-white p-4 text-right transition hover:border-sky-300 hover:shadow-md dark:border-slate-800 dark:bg-slate-900 dark:hover:border-sky-800 md:text-left">
          <div className="text-xs text-slate-400">Next Article →</div>
          <div className="mt-1 font-bold text-slate-700 dark:text-slate-200">{next.title}</div>
        </a>
      )}
    </div>
  );
}
